create function box_below(box, box) returns boolean
    language internal
as
$$box_below$$;

comment on function box_below(box, box) is 'implementation of <<| operator';

