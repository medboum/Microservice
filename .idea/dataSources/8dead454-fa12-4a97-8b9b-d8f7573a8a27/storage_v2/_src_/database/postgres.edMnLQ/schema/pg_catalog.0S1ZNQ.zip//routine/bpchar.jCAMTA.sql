create function bpchar(name) returns character
    language internal
as
$$name_bpchar$$;

comment on function bpchar(bpchar, int4, bool) is 'adjust char() to typmod length';

