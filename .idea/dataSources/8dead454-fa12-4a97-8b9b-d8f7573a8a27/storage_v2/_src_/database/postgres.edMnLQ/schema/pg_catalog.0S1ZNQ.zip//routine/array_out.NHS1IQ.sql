create function array_out(anyarray) returns cstring
    language internal
as
$$array_out$$;

comment on function array_out(anyarray) is 'I/O';

