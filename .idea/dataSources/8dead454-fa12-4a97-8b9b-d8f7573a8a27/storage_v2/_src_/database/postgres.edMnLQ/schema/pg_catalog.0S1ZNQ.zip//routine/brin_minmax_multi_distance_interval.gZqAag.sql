create function brin_minmax_multi_distance_interval(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_interval$$;

comment on function brin_minmax_multi_distance_interval(internal, internal) is 'BRIN multi minmax interval distance';

