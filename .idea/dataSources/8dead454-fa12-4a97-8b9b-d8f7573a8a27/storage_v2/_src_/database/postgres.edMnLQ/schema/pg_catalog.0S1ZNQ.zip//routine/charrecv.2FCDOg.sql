create function charrecv(internal) returns "char"
    language internal
as
$$charrecv$$;

comment on function charrecv(internal) is 'I/O';

