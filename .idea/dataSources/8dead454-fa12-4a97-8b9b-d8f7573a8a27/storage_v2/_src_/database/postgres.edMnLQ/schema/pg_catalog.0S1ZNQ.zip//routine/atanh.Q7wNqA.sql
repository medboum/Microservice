create function atanh(double precision) returns double precision
    language internal
as
$$datanh$$;

comment on function atanh(float8) is 'inverse hyperbolic tangent';

