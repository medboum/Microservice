create function bytea_sortsupport(internal) returns void
    language internal
as
$$bytea_sortsupport$$;

comment on function bytea_sortsupport(internal) is 'sort support';

