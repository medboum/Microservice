create function circle(point, double precision) returns circle
    language internal
as
$$cr_circle$$;

comment on function circle(point, float8) is 'convert point and radius to circle';

