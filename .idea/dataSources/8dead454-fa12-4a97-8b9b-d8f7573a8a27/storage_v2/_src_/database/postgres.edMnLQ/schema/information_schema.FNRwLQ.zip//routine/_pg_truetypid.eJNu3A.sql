create function _pg_truetypid(pg_attribute, pg_type) returns oid
    language sql
as
$$
    begin
-- missing source code
end;
$$;

