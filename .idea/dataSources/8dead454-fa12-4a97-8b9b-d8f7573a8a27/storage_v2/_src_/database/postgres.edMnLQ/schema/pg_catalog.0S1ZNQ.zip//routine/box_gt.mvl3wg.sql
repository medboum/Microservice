create function box_gt(box, box) returns boolean
    language internal
as
$$box_gt$$;

comment on function box_gt(box, box) is 'implementation of > operator';

