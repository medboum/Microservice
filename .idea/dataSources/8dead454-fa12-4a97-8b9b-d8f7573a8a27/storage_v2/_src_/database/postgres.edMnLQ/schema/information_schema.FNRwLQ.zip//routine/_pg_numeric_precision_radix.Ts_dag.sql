create function _pg_numeric_precision_radix(typid oid, typmod integer) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

