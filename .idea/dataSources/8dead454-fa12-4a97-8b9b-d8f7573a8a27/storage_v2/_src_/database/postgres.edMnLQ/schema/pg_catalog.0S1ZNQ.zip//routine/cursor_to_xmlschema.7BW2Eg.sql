create function cursor_to_xmlschema(cursor refcursor, nulls boolean, tableforest boolean, targetns text) returns xml
    language internal
as
$$cursor_to_xmlschema$$;

comment on function cursor_to_xmlschema(refcursor, bool, bool, text) is 'map cursor structure to XML Schema';

