create function circle_sub_pt(circle, point) returns circle
    language internal
as
$$circle_sub_pt$$;

comment on function circle_sub_pt(circle, point) is 'implementation of - operator';

