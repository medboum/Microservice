create function bitcat(bit varying, bit varying) returns bit varying
    language internal
as
$$bitcat$$;

comment on function bitcat(varbit, varbit) is 'implementation of || operator';

