create function cash_recv(internal) returns money
    language internal
as
$$cash_recv$$;

comment on function cash_recv(internal) is 'I/O';

