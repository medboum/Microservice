create function arraycontsel(internal, oid, internal, integer) returns double precision
    language internal
as
$$arraycontsel$$;

comment on function arraycontsel(internal, oid, internal, int4) is 'restriction selectivity for array-containment operators';

