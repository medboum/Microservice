create function anyrange_in(cstring, oid, integer) returns anyrange
    language internal
as
$$anyrange_in$$;

comment on function anyrange_in(cstring, oid, int4) is 'I/O';

