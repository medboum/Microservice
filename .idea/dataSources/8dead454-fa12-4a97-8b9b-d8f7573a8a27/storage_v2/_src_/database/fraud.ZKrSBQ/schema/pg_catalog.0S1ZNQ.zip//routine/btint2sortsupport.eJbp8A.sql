create function btint2sortsupport(internal) returns void
    language internal
as
$$btint2sortsupport$$;

comment on function btint2sortsupport(internal) is 'sort support';

