create function brin_bloom_options(internal) returns void
    language internal
as
$$brin_bloom_options$$;

comment on function brin_bloom_options(internal) is 'BRIN bloom support';

