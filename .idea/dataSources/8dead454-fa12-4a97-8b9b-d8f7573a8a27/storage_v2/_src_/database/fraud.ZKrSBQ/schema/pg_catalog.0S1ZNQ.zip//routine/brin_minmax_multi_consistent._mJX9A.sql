create function brin_minmax_multi_consistent(internal, internal, internal, integer) returns boolean
    language internal
as
$$brin_minmax_multi_consistent$$;

comment on function brin_minmax_multi_consistent(internal, internal, internal, int4) is 'BRIN multi minmax support';

