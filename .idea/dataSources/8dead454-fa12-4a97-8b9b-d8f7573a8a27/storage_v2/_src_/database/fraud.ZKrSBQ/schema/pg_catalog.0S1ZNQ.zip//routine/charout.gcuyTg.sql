create function charout("char") returns cstring
    language internal
as
$$charout$$;

comment on function charout("char") is 'I/O';

