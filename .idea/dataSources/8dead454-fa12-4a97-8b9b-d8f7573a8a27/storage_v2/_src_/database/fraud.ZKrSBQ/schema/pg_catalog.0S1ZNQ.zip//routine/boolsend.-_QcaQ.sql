create function boolsend(boolean) returns bytea
    language internal
as
$$boolsend$$;

comment on function boolsend(bool) is 'I/O';

