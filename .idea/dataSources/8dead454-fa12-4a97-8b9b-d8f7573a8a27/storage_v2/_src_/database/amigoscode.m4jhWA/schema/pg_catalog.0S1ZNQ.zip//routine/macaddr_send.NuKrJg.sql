create function macaddr_send(macaddr) returns bytea
    language internal
as
$$macaddr_send$$;

comment on function macaddr_send(macaddr) is 'I/O';

