create function pg_backup_stop(wait_for_archive boolean DEFAULT true, OUT lsn pg_lsn, OUT labelfile text, OUT spcmapfile text) returns record
    language internal
as
$$pg_backup_stop$$;

comment on function pg_backup_stop(bool, out pg_lsn, out text, out text) is 'finish taking an online backup';

