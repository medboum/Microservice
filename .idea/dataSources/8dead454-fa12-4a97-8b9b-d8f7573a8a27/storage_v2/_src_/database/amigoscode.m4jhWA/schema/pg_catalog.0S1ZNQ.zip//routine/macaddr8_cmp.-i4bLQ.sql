create function macaddr8_cmp(macaddr8, macaddr8) returns integer
    language internal
as
$$macaddr8_cmp$$;

comment on function macaddr8_cmp(macaddr8, macaddr8) is 'less-equal-greater';

