create function numeric_gt(numeric, numeric) returns boolean
    language internal
as
$$numeric_gt$$;

comment on function numeric_gt(numeric, numeric) is 'implementation of > operator';

