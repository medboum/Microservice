create function pg_get_function_arg_default(oid, integer) returns text
    language internal
as
$$pg_get_function_arg_default$$;

comment on function pg_get_function_arg_default(oid, int4) is 'function argument default';

