create function multirange_adjacent_range(anymultirange, anyrange) returns boolean
    language internal
as
$$multirange_adjacent_range$$;

comment on function multirange_adjacent_range(anymultirange, anyrange) is 'implementation of -|- operator';

