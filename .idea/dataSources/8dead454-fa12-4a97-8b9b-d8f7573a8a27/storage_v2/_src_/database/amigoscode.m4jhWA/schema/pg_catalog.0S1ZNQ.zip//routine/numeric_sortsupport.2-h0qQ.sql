create function numeric_sortsupport(internal) returns void
    language internal
as
$$numeric_sortsupport$$;

comment on function numeric_sortsupport(internal) is 'sort support';

