create function macaddr_ge(macaddr, macaddr) returns boolean
    language internal
as
$$macaddr_ge$$;

comment on function macaddr_ge(macaddr, macaddr) is 'implementation of >= operator';

