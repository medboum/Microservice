create function numeric_poly_stddev_pop(internal) returns numeric
    language internal
as
$$numeric_poly_stddev_pop$$;

comment on function numeric_poly_stddev_pop(internal) is 'aggregate final function';

