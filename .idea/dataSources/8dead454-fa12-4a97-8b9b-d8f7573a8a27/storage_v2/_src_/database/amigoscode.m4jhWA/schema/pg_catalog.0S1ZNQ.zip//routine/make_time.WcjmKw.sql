create function make_time(hour integer, min integer, sec double precision) returns time without time zone
    language internal
as
$$make_time$$;

comment on function make_time(int4, int4, float8) is 'construct time';

