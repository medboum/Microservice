create function numeric_var_pop(internal) returns numeric
    language internal
as
$$numeric_var_pop$$;

comment on function numeric_var_pop(internal) is 'aggregate final function';

