create function pg_copy_logical_replication_slot(src_slot_name name, dst_slot_name name, temporary boolean, plugin name, OUT slot_name name, OUT lsn pg_lsn) returns record
    language internal
as
$$pg_copy_logical_replication_slot_a$$;

comment on function pg_copy_logical_replication_slot(name, name, bool, out name, out pg_lsn) is 'copy a logical replication slot, changing temporality';

