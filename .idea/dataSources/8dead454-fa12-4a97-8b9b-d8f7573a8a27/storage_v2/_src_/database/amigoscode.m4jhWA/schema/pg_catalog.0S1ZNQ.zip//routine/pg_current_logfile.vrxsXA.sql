create function pg_current_logfile("$1" text) returns text
    language internal
as
$$pg_current_logfile$$;

comment on function pg_current_logfile(text) is 'current logging collector file location';

