create function numeric_sqrt(numeric) returns numeric
    language internal
as
$$numeric_sqrt$$;

comment on function numeric_sqrt(numeric) is 'square root';

