create function pg_get_statisticsobjdef_expressions(oid) returns text[]
    language internal
as
$$pg_get_statisticsobjdef_expressions$$;

comment on function pg_get_statisticsobjdef_expressions(oid) is 'extended statistics expressions';

