create function pg_function_is_visible(oid) returns boolean
    language internal
as
$$pg_function_is_visible$$;

comment on function pg_function_is_visible(oid) is 'is function visible in search path?';

