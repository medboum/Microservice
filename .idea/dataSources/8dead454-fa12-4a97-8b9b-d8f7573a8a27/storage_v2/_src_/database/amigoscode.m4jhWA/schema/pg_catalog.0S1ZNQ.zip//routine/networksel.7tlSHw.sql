create function networksel(internal, oid, internal, integer) returns double precision
    language internal
as
$$networksel$$;

comment on function networksel(internal, oid, internal, int4) is 'restriction selectivity for network operators';

