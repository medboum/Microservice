create function neqsel(internal, oid, internal, integer) returns double precision
    language internal
as
$$neqsel$$;

comment on function neqsel(internal, oid, internal, int4) is 'restriction selectivity of <> and related operators';

