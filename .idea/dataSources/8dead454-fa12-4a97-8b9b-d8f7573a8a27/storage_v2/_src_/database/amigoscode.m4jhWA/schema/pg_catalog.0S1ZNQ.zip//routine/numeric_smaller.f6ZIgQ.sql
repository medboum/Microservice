create function numeric_smaller(numeric, numeric) returns numeric
    language internal
as
$$numeric_smaller$$;

comment on function numeric_smaller(numeric, numeric) is 'smaller of two';

