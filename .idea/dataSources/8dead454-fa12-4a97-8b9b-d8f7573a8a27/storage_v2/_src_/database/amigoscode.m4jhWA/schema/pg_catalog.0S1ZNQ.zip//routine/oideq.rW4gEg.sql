create function oideq(oid, oid) returns boolean
    language internal
as
$$oideq$$;

comment on function oideq(oid, oid) is 'implementation of = operator';

