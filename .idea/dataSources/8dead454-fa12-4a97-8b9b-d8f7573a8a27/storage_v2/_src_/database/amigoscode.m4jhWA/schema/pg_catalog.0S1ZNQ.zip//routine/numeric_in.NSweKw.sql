create function numeric_in(cstring, oid, integer) returns numeric
    language internal
as
$$numeric_in$$;

comment on function numeric_in(cstring, oid, int4) is 'I/O';

