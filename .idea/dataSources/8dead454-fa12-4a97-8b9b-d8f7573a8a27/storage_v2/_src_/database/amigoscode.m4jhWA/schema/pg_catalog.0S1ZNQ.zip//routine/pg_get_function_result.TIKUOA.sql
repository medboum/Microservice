create function pg_get_function_result(oid) returns text
    language internal
as
$$pg_get_function_result$$;

comment on function pg_get_function_result(oid) is 'result type of a function';

