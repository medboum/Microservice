create function numeric_avg(internal) returns numeric
    language internal
as
$$numeric_avg$$;

comment on function numeric_avg(internal) is 'aggregate final function';

