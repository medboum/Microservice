create function nlikejoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$nlikejoinsel$$;

comment on function nlikejoinsel(internal, oid, internal, int2, internal) is 'join selectivity of NOT LIKE';

