create function pg_index_column_has_property(regclass, integer, text) returns boolean
    language internal
as
$$pg_index_column_has_property$$;

comment on function pg_index_column_has_property(regclass, int4, text) is 'test property of an index column';

