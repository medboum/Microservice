create function pg_event_trigger_dropped_objects(OUT classid oid, OUT objid oid, OUT objsubid integer, OUT original boolean, OUT normal boolean, OUT is_temporary boolean, OUT object_type text, OUT schema_name text, OUT object_name text, OUT object_identity text, OUT address_names text[], OUT address_args text[]) returns SETOF record
    language internal
as
$$pg_event_trigger_dropped_objects$$;

comment on function pg_event_trigger_dropped_objects(out oid, out oid, out int4, out bool, out bool, out bool, out text, out text, out text, out text, out _text, out _text) is 'list objects dropped by the current command';

