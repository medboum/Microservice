create function make_timestamptz(year integer, month integer, mday integer, hour integer, min integer, sec double precision) returns timestamp with time zone
    language internal
as
$$make_timestamptz$$;

comment on function make_timestamptz(int4, int4, int4, int4, int4, float8, text) is 'construct timestamp with time zone';

