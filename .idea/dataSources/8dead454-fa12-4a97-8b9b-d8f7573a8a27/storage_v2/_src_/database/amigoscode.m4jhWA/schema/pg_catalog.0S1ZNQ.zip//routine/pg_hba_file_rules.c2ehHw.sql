create function pg_hba_file_rules(OUT line_number integer, OUT type text, OUT database text[], OUT user_name text[], OUT address text, OUT netmask text, OUT auth_method text, OUT options text[], OUT error text) returns SETOF record
    language internal
as
$$pg_hba_file_rules$$;

comment on function pg_hba_file_rules(out int4, out text, out _text, out _text, out text, out text, out text, out _text, out text) is 'show pg_hba.conf rules';

