create function ltrim(text, text) returns text
    language internal
as
$$ltrim$$;

comment on function ltrim(text, text) is 'trim selected characters from left end of string';

