create function numeric_mul(numeric, numeric) returns numeric
    language internal
as
$$numeric_mul$$;

comment on function numeric_mul(numeric, numeric) is 'implementation of * operator';

