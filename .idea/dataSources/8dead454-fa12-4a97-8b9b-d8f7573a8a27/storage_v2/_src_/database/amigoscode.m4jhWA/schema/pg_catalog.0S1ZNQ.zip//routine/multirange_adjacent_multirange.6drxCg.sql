create function multirange_adjacent_multirange(anymultirange, anymultirange) returns boolean
    language internal
as
$$multirange_adjacent_multirange$$;

comment on function multirange_adjacent_multirange(anymultirange, anymultirange) is 'implementation of -|- operator';

