create function pg_conversion_is_visible(oid) returns boolean
    language internal
as
$$pg_conversion_is_visible$$;

comment on function pg_conversion_is_visible(oid) is 'is conversion visible in search path?';

