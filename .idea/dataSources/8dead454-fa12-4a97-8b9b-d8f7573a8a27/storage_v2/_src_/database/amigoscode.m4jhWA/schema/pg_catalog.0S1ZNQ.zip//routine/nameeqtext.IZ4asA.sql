create function nameeqtext(name, text) returns boolean
    language internal
as
$$nameeqtext$$;

comment on function nameeqtext(name, text) is 'implementation of = operator';

