create function ltrim(text, text) returns text
    language internal
as
$$ltrim$$;

comment on function ltrim(text) is 'trim spaces from left end of string';

