create function macaddr_and(macaddr, macaddr) returns macaddr
    language internal
as
$$macaddr_and$$;

comment on function macaddr_and(macaddr, macaddr) is 'implementation of & operator';

