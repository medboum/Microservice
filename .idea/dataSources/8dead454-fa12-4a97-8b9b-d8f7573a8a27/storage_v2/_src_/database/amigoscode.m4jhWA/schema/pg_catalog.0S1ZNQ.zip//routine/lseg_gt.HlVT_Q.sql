create function lseg_gt(lseg, lseg) returns boolean
    language internal
as
$$lseg_gt$$;

comment on function lseg_gt(lseg, lseg) is 'implementation of > operator';

