create function namesend(name) returns bytea
    language internal
as
$$namesend$$;

comment on function namesend(name) is 'I/O';

