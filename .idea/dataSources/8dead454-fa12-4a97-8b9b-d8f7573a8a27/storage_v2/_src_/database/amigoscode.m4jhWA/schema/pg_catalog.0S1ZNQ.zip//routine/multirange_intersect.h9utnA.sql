create function multirange_intersect(anymultirange, anymultirange) returns anymultirange
    language internal
as
$$multirange_intersect$$;

comment on function multirange_intersect(anymultirange, anymultirange) is 'implementation of * operator';

