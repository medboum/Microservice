create function lseg_in(cstring) returns lseg
    language internal
as
$$lseg_in$$;

comment on function lseg_in(cstring) is 'I/O';

