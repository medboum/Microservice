create function pg_ddl_command_send(pg_ddl_command) returns bytea
    language internal
as
$$pg_ddl_command_send$$;

comment on function pg_ddl_command_send(pg_ddl_command) is 'I/O';

