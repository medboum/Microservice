create function lseg_send(lseg) returns bytea
    language internal
as
$$lseg_send$$;

comment on function lseg_send(lseg) is 'I/O';

