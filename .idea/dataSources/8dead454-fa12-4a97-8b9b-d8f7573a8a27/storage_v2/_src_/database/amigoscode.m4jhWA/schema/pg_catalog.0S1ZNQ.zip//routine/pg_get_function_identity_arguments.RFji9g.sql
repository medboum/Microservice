create function pg_get_function_identity_arguments(oid) returns text
    language internal
as
$$pg_get_function_identity_arguments$$;

comment on function pg_get_function_identity_arguments(oid) is 'identity argument list of a function';

