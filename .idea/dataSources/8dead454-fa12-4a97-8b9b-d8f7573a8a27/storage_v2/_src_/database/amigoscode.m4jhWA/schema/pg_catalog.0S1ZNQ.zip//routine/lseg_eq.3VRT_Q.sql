create function lseg_eq(lseg, lseg) returns boolean
    language internal
as
$$lseg_eq$$;

comment on function lseg_eq(lseg, lseg) is 'implementation of = operator';

