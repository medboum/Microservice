create function money(numeric) returns money
    language internal
as
$$numeric_cash$$;

comment on function money(int8) is 'convert int8 to money';

