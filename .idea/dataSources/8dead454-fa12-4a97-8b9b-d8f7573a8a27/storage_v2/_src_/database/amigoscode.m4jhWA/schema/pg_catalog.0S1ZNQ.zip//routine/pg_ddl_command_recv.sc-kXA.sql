create function pg_ddl_command_recv(internal) returns pg_ddl_command
    language internal
as
$$pg_ddl_command_recv$$;

comment on function pg_ddl_command_recv(internal) is 'I/O';

