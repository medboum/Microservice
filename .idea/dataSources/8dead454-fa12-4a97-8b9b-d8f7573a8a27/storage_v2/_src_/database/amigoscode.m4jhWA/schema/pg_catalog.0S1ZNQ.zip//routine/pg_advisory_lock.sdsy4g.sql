create function pg_advisory_lock(bigint) returns void
    language internal
as
$$pg_advisory_lock_int8$$;

comment on function pg_advisory_lock(int8) is 'obtain exclusive advisory lock';

