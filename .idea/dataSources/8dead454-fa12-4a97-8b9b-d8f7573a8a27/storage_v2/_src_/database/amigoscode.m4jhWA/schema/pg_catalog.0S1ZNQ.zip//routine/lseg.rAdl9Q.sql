create function lseg(box) returns lseg
    language internal
as
$$box_diagonal$$;

comment on function lseg(point, point) is 'convert points to line segment';

