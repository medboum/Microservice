create function numeric_ln(numeric) returns numeric
    language internal
as
$$numeric_ln$$;

comment on function numeric_ln(numeric) is 'natural logarithm';

