create function pg_advisory_unlock_all() returns void
    language internal
as
$$pg_advisory_unlock_all$$;

comment on function pg_advisory_unlock_all() is 'release all advisory locks';

