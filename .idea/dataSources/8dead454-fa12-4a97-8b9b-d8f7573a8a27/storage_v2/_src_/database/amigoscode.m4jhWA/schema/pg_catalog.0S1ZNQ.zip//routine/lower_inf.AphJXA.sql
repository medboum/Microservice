create function lower_inf(anyrange) returns boolean
    language internal
as
$$range_lower_inf$$;

comment on function lower_inf(anymultirange) is 'is the multirange''s lower bound infinite?';

