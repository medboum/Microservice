create function namelttext(name, text) returns boolean
    language internal
as
$$namelttext$$;

comment on function namelttext(name, text) is 'implementation of < operator';

