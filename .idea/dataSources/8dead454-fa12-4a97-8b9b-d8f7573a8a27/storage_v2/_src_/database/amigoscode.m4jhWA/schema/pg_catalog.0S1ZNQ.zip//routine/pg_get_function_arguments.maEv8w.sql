create function pg_get_function_arguments(oid) returns text
    language internal
as
$$pg_get_function_arguments$$;

comment on function pg_get_function_arguments(oid) is 'argument list of a function';

