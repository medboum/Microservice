create function lseg_horizontal(lseg) returns boolean
    language internal
as
$$lseg_horizontal$$;

comment on function lseg_horizontal(lseg) is 'implementation of ?- operator';

