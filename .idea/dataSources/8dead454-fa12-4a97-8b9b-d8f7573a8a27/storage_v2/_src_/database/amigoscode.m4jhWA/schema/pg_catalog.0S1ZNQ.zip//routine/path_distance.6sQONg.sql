create function path_distance(path, path) returns double precision
    language internal
as
$$path_distance$$;

comment on function path_distance(path, path) is 'implementation of <-> operator';

