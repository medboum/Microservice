create function macaddr8_recv(internal) returns macaddr8
    language internal
as
$$macaddr8_recv$$;

comment on function macaddr8_recv(internal) is 'I/O';

