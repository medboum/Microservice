create function loread(integer, integer) returns bytea
    language internal
as
$$be_loread$$;

comment on function loread(int4, int4) is 'large object read';

