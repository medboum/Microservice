create function pg_client_encoding() returns name
    language internal
as
$$pg_client_encoding$$;

comment on function pg_client_encoding() is 'encoding name of current database';

