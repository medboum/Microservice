create function pg_get_viewdef(text) returns text
    language internal
as
$$pg_get_viewdef_name$$;

comment on function pg_get_viewdef(oid) is 'select statement of a view';

