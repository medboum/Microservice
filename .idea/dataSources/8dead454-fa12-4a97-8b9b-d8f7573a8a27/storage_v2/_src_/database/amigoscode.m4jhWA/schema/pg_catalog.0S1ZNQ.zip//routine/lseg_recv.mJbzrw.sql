create function lseg_recv(internal) returns lseg
    language internal
as
$$lseg_recv$$;

comment on function lseg_recv(internal) is 'I/O';

