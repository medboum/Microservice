create function "overlaps"(time with time zone, time with time zone, time with time zone, time with time zone) returns boolean
    language internal
as
$$overlaps_timetz$$;

comment on function "overlaps"(timestamptz, interval, timestamptz, timestamptz) is 'intervals overlap?';

