create function namein(cstring) returns name
    language internal
as
$$namein$$;

comment on function namein(cstring) is 'I/O';

