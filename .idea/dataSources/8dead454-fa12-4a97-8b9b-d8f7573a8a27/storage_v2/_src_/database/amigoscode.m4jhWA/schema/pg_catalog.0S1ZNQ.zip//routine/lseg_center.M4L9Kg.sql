create function lseg_center(lseg) returns point
    language internal
as
$$lseg_center$$;

comment on function lseg_center(lseg) is 'implementation of @@ operator';

