create function pg_current_wal_flush_lsn() returns pg_lsn
    language internal
as
$$pg_current_wal_flush_lsn$$;

comment on function pg_current_wal_flush_lsn() is 'current wal flush location';

