create function multirange_intersect_agg_transfn(anymultirange, anymultirange) returns anymultirange
    language internal
as
$$multirange_intersect_agg_transfn$$;

comment on function multirange_intersect_agg_transfn(anymultirange, anymultirange) is 'range aggregate by intersecting';

