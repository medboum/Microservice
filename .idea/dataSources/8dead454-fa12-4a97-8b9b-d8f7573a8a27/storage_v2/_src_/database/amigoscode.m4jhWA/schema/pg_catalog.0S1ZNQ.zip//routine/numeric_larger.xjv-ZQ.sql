create function numeric_larger(numeric, numeric) returns numeric
    language internal
as
$$numeric_larger$$;

comment on function numeric_larger(numeric, numeric) is 'larger of two';

