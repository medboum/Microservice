create function numeric(money) returns numeric
    language internal
as
$$cash_numeric$$;

comment on function numeric(int8) is 'convert int8 to numeric';

