create function pg_current_xact_id_if_assigned() returns xid8
    language internal
as
$$pg_current_xact_id_if_assigned$$;

comment on function pg_current_xact_id_if_assigned() is 'get current transaction ID';

