create function lower_inc(anyrange) returns boolean
    language internal
as
$$range_lower_inc$$;

comment on function lower_inc(anyrange) is 'is the range''s lower bound inclusive?';

