create function pg_advisory_xact_lock(bigint) returns void
    language internal
as
$$pg_advisory_xact_lock_int8$$;

comment on function pg_advisory_xact_lock(int4, int4) is 'obtain exclusive advisory lock';

