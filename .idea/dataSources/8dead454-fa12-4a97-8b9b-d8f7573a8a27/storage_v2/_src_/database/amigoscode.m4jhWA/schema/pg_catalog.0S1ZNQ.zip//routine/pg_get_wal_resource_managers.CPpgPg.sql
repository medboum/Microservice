create function pg_get_wal_resource_managers(OUT rm_id integer, OUT rm_name text, OUT rm_builtin boolean) returns SETOF record
    language internal
as
$$pg_get_wal_resource_managers$$;

comment on function pg_get_wal_resource_managers(out int4, out text, out bool) is 'get resource managers loaded in system';

