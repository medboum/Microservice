create function network_subeq(inet, inet) returns boolean
    language internal
as
$$network_subeq$$;

comment on function network_subeq(inet, inet) is 'implementation of <<= operator';

