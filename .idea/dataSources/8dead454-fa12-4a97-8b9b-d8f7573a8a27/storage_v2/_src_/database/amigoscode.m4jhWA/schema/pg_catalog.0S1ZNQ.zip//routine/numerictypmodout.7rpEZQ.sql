create function numerictypmodout(integer) returns cstring
    language internal
as
$$numerictypmodout$$;

comment on function numerictypmodout(int4) is 'I/O typmod';

