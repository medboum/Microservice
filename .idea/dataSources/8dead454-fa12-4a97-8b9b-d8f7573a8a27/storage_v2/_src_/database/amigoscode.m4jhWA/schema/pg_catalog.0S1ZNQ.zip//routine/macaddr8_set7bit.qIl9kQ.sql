create function macaddr8_set7bit(macaddr8) returns macaddr8
    language internal
as
$$macaddr8_set7bit$$;

comment on function macaddr8_set7bit(macaddr8) is 'set 7th bit in macaddr8';

