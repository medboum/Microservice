create function mxid_age(xid) returns integer
    language internal
as
$$mxid_age$$;

comment on function mxid_age(xid) is 'age of a multi-transaction ID, in multi-transactions before current multi-transaction';

