create function macaddr_gt(macaddr, macaddr) returns boolean
    language internal
as
$$macaddr_gt$$;

comment on function macaddr_gt(macaddr, macaddr) is 'implementation of > operator';

