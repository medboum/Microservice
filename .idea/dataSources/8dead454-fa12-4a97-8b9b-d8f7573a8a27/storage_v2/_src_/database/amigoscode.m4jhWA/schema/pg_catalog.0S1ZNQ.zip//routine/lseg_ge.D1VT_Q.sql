create function lseg_ge(lseg, lseg) returns boolean
    language internal
as
$$lseg_ge$$;

comment on function lseg_ge(lseg, lseg) is 'implementation of >= operator';

