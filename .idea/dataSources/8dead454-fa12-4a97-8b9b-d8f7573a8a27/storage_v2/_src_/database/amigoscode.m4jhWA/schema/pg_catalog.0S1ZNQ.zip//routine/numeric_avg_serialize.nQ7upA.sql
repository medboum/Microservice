create function numeric_avg_serialize(internal) returns bytea
    language internal
as
$$numeric_avg_serialize$$;

comment on function numeric_avg_serialize(internal) is 'aggregate serial function';

