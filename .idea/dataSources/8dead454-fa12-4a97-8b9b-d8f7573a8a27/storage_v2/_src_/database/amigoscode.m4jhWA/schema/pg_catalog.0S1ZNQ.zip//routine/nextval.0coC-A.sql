create function nextval(regclass) returns bigint
    language internal
as
$$nextval_oid$$;

comment on function nextval(regclass) is 'sequence next value';

