create function numeric_sum(internal) returns numeric
    language internal
as
$$numeric_sum$$;

comment on function numeric_sum(internal) is 'aggregate final function';

