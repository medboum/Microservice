create function notlike(text, text) returns boolean
    language internal
as
$$textnlike$$;

comment on function notlike(text, text) is 'does not match LIKE expression';

