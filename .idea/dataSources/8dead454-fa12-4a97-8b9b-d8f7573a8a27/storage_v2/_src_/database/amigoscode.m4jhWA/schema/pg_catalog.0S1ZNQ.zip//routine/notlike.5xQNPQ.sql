create function notlike(text, text) returns boolean
    language internal
as
$$textnlike$$;

comment on function notlike(name, text) is 'does not match LIKE expression';

