create function oidin(cstring) returns oid
    language internal
as
$$oidin$$;

comment on function oidin(cstring) is 'I/O';

