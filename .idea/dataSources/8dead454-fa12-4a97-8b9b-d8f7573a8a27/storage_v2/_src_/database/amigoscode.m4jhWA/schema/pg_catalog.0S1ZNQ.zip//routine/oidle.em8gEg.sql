create function oidle(oid, oid) returns boolean
    language internal
as
$$oidle$$;

comment on function oidle(oid, oid) is 'implementation of <= operator';

