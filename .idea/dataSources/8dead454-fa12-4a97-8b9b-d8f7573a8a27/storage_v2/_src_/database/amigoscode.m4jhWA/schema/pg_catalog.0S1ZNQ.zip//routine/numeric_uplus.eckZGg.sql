create function numeric_uplus(numeric) returns numeric
    language internal
as
$$numeric_uplus$$;

comment on function numeric_uplus(numeric) is 'implementation of + operator';

