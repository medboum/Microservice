create function multirange_typanalyze(internal) returns boolean
    language internal
as
$$multirange_typanalyze$$;

comment on function multirange_typanalyze(internal) is 'multirange typanalyze';

