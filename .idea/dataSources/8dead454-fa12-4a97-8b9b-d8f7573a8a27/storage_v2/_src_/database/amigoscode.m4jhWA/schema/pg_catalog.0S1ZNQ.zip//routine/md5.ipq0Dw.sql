create function md5(bytea) returns text
    language internal
as
$$md5_bytea$$;

comment on function md5(text) is 'MD5 hash';

