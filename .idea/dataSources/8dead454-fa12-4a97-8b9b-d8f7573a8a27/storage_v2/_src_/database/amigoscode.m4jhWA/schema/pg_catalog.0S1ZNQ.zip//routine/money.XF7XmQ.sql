create function money(numeric) returns money
    language internal
as
$$numeric_cash$$;

comment on function money(numeric) is 'convert numeric to money';

