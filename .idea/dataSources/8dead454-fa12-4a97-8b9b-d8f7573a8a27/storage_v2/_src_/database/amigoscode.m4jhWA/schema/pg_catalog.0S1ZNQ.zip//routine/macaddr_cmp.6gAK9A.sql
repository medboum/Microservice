create function macaddr_cmp(macaddr, macaddr) returns integer
    language internal
as
$$macaddr_cmp$$;

comment on function macaddr_cmp(macaddr, macaddr) is 'less-equal-greater';

