create function network_eq(inet, inet) returns boolean
    language internal
as
$$network_eq$$;

comment on function network_eq(inet, inet) is 'implementation of = operator';

