create function lseg_out(lseg) returns cstring
    language internal
as
$$lseg_out$$;

comment on function lseg_out(lseg) is 'I/O';

