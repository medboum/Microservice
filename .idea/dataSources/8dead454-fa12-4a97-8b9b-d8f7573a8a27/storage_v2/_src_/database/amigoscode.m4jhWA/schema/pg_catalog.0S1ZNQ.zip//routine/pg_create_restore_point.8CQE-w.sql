create function pg_create_restore_point(text) returns pg_lsn
    language internal
as
$$pg_create_restore_point$$;

comment on function pg_create_restore_point(text) is 'create a named restore point';

