create function numeric_avg_accum(internal, numeric) returns internal
    language internal
as
$$numeric_avg_accum$$;

comment on function numeric_avg_accum(internal, numeric) is 'aggregate transition function';

