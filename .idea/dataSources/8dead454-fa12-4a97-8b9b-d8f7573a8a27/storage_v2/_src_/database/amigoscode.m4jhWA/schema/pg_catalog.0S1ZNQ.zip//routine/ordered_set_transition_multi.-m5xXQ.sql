create function ordered_set_transition_multi(internal, VARIADIC "any") returns internal
    language internal
as
$$ordered_set_transition_multi$$;

comment on function ordered_set_transition_multi(internal, any) is 'aggregate transition function';

