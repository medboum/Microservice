create function path_length(path) returns double precision
    language internal
as
$$path_length$$;

comment on function path_length(path) is 'implementation of @-@ operator';

