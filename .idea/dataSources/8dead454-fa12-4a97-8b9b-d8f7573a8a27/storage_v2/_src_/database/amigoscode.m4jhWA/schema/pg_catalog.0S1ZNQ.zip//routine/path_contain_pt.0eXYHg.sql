create function path_contain_pt(path, point) returns boolean
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function path_contain_pt(path, point) is 'implementation of @> operator';

