create function multirange_send(anymultirange) returns bytea
    language internal
as
$$multirange_send$$;

comment on function multirange_send(anymultirange) is 'I/O';

