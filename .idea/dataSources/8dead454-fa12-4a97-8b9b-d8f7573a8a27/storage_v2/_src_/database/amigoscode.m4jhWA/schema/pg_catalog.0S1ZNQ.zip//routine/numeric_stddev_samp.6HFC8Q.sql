create function numeric_stddev_samp(internal) returns numeric
    language internal
as
$$numeric_stddev_samp$$;

comment on function numeric_stddev_samp(internal) is 'aggregate final function';

