create function oidvectorout(oidvector) returns cstring
    language internal
as
$$oidvectorout$$;

comment on function oidvectorout(oidvector) is 'I/O';

