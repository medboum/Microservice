create function nameicregexne(name, text) returns boolean
    language internal
as
$$nameicregexne$$;

comment on function nameicregexne(name, text) is 'implementation of !~* operator';

