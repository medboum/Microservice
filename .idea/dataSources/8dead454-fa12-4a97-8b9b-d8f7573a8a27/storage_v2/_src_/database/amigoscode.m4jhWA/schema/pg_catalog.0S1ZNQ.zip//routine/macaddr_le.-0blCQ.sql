create function macaddr_le(macaddr, macaddr) returns boolean
    language internal
as
$$macaddr_le$$;

comment on function macaddr_le(macaddr, macaddr) is 'implementation of <= operator';

