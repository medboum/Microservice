create function pg_indexes_size(regclass) returns bigint
    language internal
as
$$pg_indexes_size$$;

comment on function pg_indexes_size(regclass) is 'disk space usage for all indexes attached to the specified table';

