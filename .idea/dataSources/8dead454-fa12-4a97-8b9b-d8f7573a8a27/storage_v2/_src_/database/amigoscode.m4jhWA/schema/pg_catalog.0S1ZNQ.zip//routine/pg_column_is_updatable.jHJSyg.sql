create function pg_column_is_updatable(regclass, smallint, boolean) returns boolean
    language internal
as
$$pg_column_is_updatable$$;

comment on function pg_column_is_updatable(regclass, int2, bool) is 'is a column updatable';

