create function lseg_interpt(lseg, lseg) returns point
    language internal
as
$$lseg_interpt$$;

comment on function lseg_interpt(lseg, lseg) is 'implementation of # operator';

