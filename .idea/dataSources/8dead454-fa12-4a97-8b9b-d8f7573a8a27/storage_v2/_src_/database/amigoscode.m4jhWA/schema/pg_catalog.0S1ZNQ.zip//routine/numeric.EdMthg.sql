create function numeric(money) returns numeric
    language internal
as
$$cash_numeric$$;

comment on function numeric(int4) is 'convert int4 to numeric';

