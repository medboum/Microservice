create function oidvectorin(cstring) returns oidvector
    language internal
as
$$oidvectorin$$;

comment on function oidvectorin(cstring) is 'I/O';

