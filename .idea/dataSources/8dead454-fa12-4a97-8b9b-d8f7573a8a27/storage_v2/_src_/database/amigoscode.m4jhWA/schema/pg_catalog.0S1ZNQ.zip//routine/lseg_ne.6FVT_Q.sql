create function lseg_ne(lseg, lseg) returns boolean
    language internal
as
$$lseg_ne$$;

comment on function lseg_ne(lseg, lseg) is 'implementation of <> operator';

