create function multirange_after_range(anymultirange, anyrange) returns boolean
    language internal
as
$$multirange_after_range$$;

comment on function multirange_after_range(anymultirange, anyrange) is 'implementation of >> operator';

