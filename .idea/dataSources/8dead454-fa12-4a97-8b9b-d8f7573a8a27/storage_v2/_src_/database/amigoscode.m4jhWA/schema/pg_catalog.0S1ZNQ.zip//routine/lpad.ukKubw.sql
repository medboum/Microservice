create function lpad(text, integer) returns text
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function lpad(text, int4) is 'left-pad string to length';

