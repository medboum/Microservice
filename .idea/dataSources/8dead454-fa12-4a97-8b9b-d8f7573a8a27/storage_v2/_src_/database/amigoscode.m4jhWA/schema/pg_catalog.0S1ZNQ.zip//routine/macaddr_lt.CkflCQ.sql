create function macaddr_lt(macaddr, macaddr) returns boolean
    language internal
as
$$macaddr_lt$$;

comment on function macaddr_lt(macaddr, macaddr) is 'implementation of < operator';

