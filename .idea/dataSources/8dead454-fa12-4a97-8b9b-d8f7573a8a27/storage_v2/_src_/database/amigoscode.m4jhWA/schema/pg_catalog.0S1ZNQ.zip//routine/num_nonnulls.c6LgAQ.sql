create function num_nonnulls(VARIADIC "any") returns integer
    language internal
as
$$pg_num_nonnulls$$;

comment on function num_nonnulls(any) is 'count the number of non-NULL arguments';

