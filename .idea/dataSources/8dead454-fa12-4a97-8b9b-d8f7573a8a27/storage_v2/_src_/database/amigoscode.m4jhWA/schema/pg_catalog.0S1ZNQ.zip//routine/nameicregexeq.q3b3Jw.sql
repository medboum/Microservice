create function nameicregexeq(name, text) returns boolean
    language internal
as
$$nameicregexeq$$;

comment on function nameicregexeq(name, text) is 'implementation of ~* operator';

