create function lseg_le(lseg, lseg) returns boolean
    language internal
as
$$lseg_le$$;

comment on function lseg_le(lseg, lseg) is 'implementation of <= operator';

