create function macaddr_ne(macaddr, macaddr) returns boolean
    language internal
as
$$macaddr_ne$$;

comment on function macaddr_ne(macaddr, macaddr) is 'implementation of <> operator';

