create function mod(smallint, smallint) returns smallint
    language internal
as
$$int2mod$$;

comment on function mod(int4, int4) is 'modulus';

