create function lower(text) returns text
    language internal
as
$$lower$$;

comment on function lower(text) is 'lowercase';

