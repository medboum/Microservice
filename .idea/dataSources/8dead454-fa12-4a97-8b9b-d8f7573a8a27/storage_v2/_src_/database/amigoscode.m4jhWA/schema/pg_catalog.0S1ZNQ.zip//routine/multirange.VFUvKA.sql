create function multirange(anyrange) returns anymultirange
    language internal
as
$$multirange_constructor1$$;

comment on function multirange(anyrange) is 'anymultirange cast';

