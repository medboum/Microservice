create function pg_drop_replication_slot(name) returns void
    language internal
as
$$pg_drop_replication_slot$$;

comment on function pg_drop_replication_slot(name) is 'drop a replication slot';

