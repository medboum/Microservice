create function pg_conf_load_time() returns timestamp with time zone
    language internal
as
$$pg_conf_load_time$$;

comment on function pg_conf_load_time() is 'configuration load time';

