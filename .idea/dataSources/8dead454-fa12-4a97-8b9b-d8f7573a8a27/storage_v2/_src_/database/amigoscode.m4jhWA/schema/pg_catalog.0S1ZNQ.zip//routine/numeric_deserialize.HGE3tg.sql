create function numeric_deserialize(bytea, internal) returns internal
    language internal
as
$$numeric_deserialize$$;

comment on function numeric_deserialize(bytea, internal) is 'aggregate deserial function';

