create function lseg_lt(lseg, lseg) returns boolean
    language internal
as
$$lseg_lt$$;

comment on function lseg_lt(lseg, lseg) is 'implementation of < operator';

