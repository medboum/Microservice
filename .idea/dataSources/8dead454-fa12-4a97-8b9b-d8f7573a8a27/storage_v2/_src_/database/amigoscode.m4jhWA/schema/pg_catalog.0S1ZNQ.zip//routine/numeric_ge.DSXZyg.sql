create function numeric_ge(numeric, numeric) returns boolean
    language internal
as
$$numeric_ge$$;

comment on function numeric_ge(numeric, numeric) is 'implementation of >= operator';

