create function path_n_le(path, path) returns boolean
    language internal
as
$$path_n_le$$;

comment on function path_n_le(path, path) is 'implementation of <= operator';

