create function pg_cursor(OUT name text, OUT statement text, OUT is_holdable boolean, OUT is_binary boolean, OUT is_scrollable boolean, OUT creation_time timestamp with time zone) returns SETOF record
    language internal
as
$$pg_cursor$$;

comment on function pg_cursor(out text, out text, out bool, out bool, out bool, out timestamptz) is 'get the open cursors for this session';

