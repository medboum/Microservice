create function pg_current_logfile() returns text
    language internal
as
$$pg_current_logfile$$;

comment on function pg_current_logfile() is 'current logging collector file location';

