create function multirange_contains_range(anymultirange, anyrange) returns boolean
    language internal
as
$$multirange_contains_range$$;

comment on function multirange_contains_range(anymultirange, anyrange) is 'implementation of @> operator';

