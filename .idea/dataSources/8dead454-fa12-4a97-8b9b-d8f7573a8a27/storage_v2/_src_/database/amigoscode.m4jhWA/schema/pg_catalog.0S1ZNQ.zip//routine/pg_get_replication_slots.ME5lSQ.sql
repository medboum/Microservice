create function pg_get_replication_slots(OUT slot_name name, OUT plugin name, OUT slot_type text, OUT datoid oid, OUT temporary boolean, OUT active boolean, OUT active_pid integer, OUT xmin xid, OUT catalog_xmin xid, OUT restart_lsn pg_lsn, OUT confirmed_flush_lsn pg_lsn, OUT wal_status text, OUT safe_wal_size bigint, OUT two_phase boolean) returns SETOF record
    language internal
as
$$pg_get_replication_slots$$;

comment on function pg_get_replication_slots(out name, out name, out text, out oid, out bool, out bool, out int4, out xid, out xid, out pg_lsn, out pg_lsn, out text, out int8, out bool) is 'information about replication slots currently in use';

