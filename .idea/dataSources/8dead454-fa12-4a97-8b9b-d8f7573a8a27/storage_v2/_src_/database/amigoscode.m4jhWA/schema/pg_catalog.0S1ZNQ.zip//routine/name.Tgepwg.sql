create function name(text) returns name
    language internal
as
$$text_name$$;

comment on function name(bpchar) is 'convert char(n) to name';

