create function masklen(inet) returns integer
    language internal
as
$$network_masklen$$;

comment on function masklen(inet) is 'netmask length';

