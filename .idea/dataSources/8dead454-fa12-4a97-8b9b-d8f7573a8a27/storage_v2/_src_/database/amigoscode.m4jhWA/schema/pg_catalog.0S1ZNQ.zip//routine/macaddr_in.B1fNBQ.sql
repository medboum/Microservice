create function macaddr_in(cstring) returns macaddr
    language internal
as
$$macaddr_in$$;

comment on function macaddr_in(cstring) is 'I/O';

