create function pg_import_system_collations(regnamespace) returns integer
    language internal
as
$$pg_import_system_collations$$;

comment on function pg_import_system_collations(regnamespace) is 'import collations from operating system';

