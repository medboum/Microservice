create function lseg_intersect(lseg, lseg) returns boolean
    language internal
as
$$lseg_intersect$$;

comment on function lseg_intersect(lseg, lseg) is 'implementation of ?# operator';

