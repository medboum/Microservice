create function numeric_cmp(numeric, numeric) returns integer
    language internal
as
$$numeric_cmp$$;

comment on function numeric_cmp(numeric, numeric) is 'less-equal-greater';

