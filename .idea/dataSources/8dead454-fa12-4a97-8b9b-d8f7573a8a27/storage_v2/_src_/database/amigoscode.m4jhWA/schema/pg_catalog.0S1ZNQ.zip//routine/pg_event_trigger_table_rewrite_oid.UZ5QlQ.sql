create function pg_event_trigger_table_rewrite_oid(OUT oid oid) returns oid
    language internal
as
$$pg_event_trigger_table_rewrite_oid$$;

comment on function pg_event_trigger_table_rewrite_oid(out oid) is 'return Oid of the table getting rewritten';

