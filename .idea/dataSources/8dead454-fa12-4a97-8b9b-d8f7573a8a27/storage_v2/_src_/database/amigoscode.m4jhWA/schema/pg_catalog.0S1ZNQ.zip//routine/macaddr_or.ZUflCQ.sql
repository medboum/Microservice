create function macaddr_or(macaddr, macaddr) returns macaddr
    language internal
as
$$macaddr_or$$;

comment on function macaddr_or(macaddr, macaddr) is 'implementation of | operator';

