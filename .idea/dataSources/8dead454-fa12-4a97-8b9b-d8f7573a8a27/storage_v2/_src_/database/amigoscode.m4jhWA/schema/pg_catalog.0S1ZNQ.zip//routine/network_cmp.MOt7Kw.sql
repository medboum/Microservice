create function network_cmp(inet, inet) returns integer
    language internal
as
$$network_cmp$$;

comment on function network_cmp(inet, inet) is 'less-equal-greater';

