create function pg_get_function_sqlbody(oid) returns text
    language internal
as
$$pg_get_function_sqlbody$$;

comment on function pg_get_function_sqlbody(oid) is 'function SQL body';

