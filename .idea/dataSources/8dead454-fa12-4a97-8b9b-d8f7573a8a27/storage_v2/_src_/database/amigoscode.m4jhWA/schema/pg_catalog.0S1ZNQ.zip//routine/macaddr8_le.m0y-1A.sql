create function macaddr8_le(macaddr8, macaddr8) returns boolean
    language internal
as
$$macaddr8_le$$;

comment on function macaddr8_le(macaddr8, macaddr8) is 'implementation of <= operator';

