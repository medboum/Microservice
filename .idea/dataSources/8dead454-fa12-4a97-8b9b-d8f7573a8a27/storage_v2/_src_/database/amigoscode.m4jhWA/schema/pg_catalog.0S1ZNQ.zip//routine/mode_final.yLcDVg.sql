create function mode_final(internal, anyelement) returns anyelement
    language internal
as
$$mode_final$$;

comment on function mode_final(internal, anyelement) is 'aggregate final function';

