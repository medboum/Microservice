create function pg_has_role(name, name, text) returns boolean
    language internal
as
$$pg_has_role_name_name$$;

comment on function pg_has_role(oid, text) is 'current user privilege on role by role oid';

