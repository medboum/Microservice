create function lseg_perp(lseg, lseg) returns boolean
    language internal
as
$$lseg_perp$$;

comment on function lseg_perp(lseg, lseg) is 'implementation of ?-| operator';

