create function numeric_stddev_pop(internal) returns numeric
    language internal
as
$$numeric_stddev_pop$$;

comment on function numeric_stddev_pop(internal) is 'aggregate final function';

