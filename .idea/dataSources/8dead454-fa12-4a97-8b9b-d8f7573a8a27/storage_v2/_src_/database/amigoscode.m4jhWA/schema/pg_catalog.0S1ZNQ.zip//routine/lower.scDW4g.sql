create function lower(text) returns text
    language internal
as
$$lower$$;

comment on function lower(anyrange) is 'lower bound of range';

