create function multirange_gist_compress(internal) returns internal
    language internal
as
$$multirange_gist_compress$$;

comment on function multirange_gist_compress(internal) is 'GiST support';

