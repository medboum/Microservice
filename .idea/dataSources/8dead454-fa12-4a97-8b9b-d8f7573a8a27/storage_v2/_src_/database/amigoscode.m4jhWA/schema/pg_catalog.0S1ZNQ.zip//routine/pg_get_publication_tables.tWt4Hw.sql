create function pg_get_publication_tables(pubname text, OUT relid oid, OUT attrs int2vector, OUT qual pg_node_tree) returns SETOF record
    language internal
as
$$pg_get_publication_tables$$;

comment on function pg_get_publication_tables(text, out oid, out int2vector, out pg_node_tree) is 'get information of tables in a publication';

