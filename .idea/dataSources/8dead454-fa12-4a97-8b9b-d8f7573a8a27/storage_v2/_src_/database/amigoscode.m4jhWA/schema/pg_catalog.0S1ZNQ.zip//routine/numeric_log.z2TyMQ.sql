create function numeric_log(numeric, numeric) returns numeric
    language internal
as
$$numeric_log$$;

comment on function numeric_log(numeric, numeric) is 'logarithm base m of n';

