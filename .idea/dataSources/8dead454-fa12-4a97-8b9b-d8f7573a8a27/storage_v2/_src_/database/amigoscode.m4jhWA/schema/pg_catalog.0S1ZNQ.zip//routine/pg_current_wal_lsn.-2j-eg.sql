create function pg_current_wal_lsn() returns pg_lsn
    language internal
as
$$pg_current_wal_lsn$$;

comment on function pg_current_wal_lsn() is 'current wal write location';

