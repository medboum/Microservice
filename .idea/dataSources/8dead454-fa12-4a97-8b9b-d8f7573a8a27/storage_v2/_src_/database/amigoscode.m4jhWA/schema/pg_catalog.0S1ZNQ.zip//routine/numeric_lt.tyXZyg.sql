create function numeric_lt(numeric, numeric) returns boolean
    language internal
as
$$numeric_lt$$;

comment on function numeric_lt(numeric, numeric) is 'implementation of < operator';

