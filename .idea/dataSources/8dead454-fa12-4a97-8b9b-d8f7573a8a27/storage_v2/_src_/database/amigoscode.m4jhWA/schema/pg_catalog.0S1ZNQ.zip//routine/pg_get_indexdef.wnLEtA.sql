create function pg_get_indexdef(oid) returns text
    language internal
as
$$pg_get_indexdef$$;

comment on function pg_get_indexdef(oid, int4, bool) is 'index description (full create statement or single expression) with pretty-print option';

