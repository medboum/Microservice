create function make_timestamp(year integer, month integer, mday integer, hour integer, min integer, sec double precision) returns timestamp without time zone
    language internal
as
$$make_timestamp$$;

comment on function make_timestamp(int4, int4, int4, int4, int4, float8) is 'construct timestamp';

