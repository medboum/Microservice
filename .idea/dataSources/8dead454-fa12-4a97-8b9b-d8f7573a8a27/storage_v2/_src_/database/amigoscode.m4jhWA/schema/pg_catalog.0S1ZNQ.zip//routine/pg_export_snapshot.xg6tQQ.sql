create function pg_export_snapshot() returns text
    language internal
as
$$pg_export_snapshot$$;

comment on function pg_export_snapshot() is 'export a snapshot';

