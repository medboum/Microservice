create function overlay(bytea, bytea, integer, integer) returns bytea
    language internal
as
$$byteaoverlay$$;

comment on function overlay(text, text, int4, int4) is 'substitute portion of string';

