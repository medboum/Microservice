create function numrange_subdiff(numeric, numeric) returns double precision
    language internal
as
$$numrange_subdiff$$;

comment on function numrange_subdiff(numeric, numeric) is 'float8 difference of two numeric values';

