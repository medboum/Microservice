create function log(double precision) returns double precision
    language internal
as
$$dlog10$$;

comment on function log(float8) is 'base 10 logarithm';

