create function macaddr(macaddr8) returns macaddr
    language internal
as
$$macaddr8tomacaddr$$;

comment on function macaddr(macaddr8) is 'convert macaddr8 to macaddr';

