create function numeric_add(numeric, numeric) returns numeric
    language internal
as
$$numeric_add$$;

comment on function numeric_add(numeric, numeric) is 'implementation of + operator';

