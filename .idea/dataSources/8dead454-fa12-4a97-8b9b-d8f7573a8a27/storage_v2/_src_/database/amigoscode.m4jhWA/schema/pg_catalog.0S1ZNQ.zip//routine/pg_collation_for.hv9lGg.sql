create function pg_collation_for("any") returns text
    language internal
as
$$pg_collation_for$$;

comment on function pg_collation_for(any) is 'collation of the argument; implementation of the COLLATION FOR expression';

