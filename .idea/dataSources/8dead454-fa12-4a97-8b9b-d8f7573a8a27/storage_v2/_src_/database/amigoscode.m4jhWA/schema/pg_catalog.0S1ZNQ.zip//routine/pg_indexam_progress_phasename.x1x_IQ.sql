create function pg_indexam_progress_phasename(oid, bigint) returns text
    language internal
as
$$pg_indexam_progress_phasename$$;

comment on function pg_indexam_progress_phasename(oid, int8) is 'return name of given index build phase';

