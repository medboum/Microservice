create function pg_get_catalog_foreign_keys(OUT fktable regclass, OUT fkcols text[], OUT pktable regclass, OUT pkcols text[], OUT is_array boolean, OUT is_opt boolean) returns SETOF record
    language internal
as
$$pg_get_catalog_foreign_keys$$;

comment on function pg_get_catalog_foreign_keys(out regclass, out _text, out regclass, out _text, out bool, out bool) is 'list of catalog foreign key relationships';

