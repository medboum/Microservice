create function money(numeric) returns money
    language internal
as
$$numeric_cash$$;

comment on function money(int4) is 'convert int4 to money';

