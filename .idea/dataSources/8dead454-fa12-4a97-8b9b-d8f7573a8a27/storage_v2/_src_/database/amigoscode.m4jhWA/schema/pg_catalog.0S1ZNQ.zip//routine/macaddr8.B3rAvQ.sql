create function macaddr8(macaddr) returns macaddr8
    language internal
as
$$macaddrtomacaddr8$$;

comment on function macaddr8(macaddr) is 'convert macaddr to macaddr8';

