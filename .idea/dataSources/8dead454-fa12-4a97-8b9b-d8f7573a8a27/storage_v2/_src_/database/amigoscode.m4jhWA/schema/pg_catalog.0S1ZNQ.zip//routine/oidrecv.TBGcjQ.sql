create function oidrecv(internal) returns oid
    language internal
as
$$oidrecv$$;

comment on function oidrecv(internal) is 'I/O';

