create function pg_identify_object(classid oid, objid oid, objsubid integer, OUT type text, OUT schema text, OUT name text, OUT identity text) returns record
    language internal
as
$$pg_identify_object$$;

comment on function pg_identify_object(oid, oid, int4, out text, out text, out text, out text) is 'get machine-parseable identification of SQL object';

