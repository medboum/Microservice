create function nlikesel(internal, oid, internal, integer) returns double precision
    language internal
as
$$nlikesel$$;

comment on function nlikesel(internal, oid, internal, int4) is 'restriction selectivity of NOT LIKE';

