create function multirange_ne(anymultirange, anymultirange) returns boolean
    language internal
as
$$multirange_ne$$;

comment on function multirange_ne(anymultirange, anymultirange) is 'implementation of <> operator';

