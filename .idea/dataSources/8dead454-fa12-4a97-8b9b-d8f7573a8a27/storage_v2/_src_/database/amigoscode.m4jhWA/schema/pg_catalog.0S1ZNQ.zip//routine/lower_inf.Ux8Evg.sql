create function lower_inf(anyrange) returns boolean
    language internal
as
$$range_lower_inf$$;

comment on function lower_inf(anyrange) is 'is the range''s lower bound infinite?';

