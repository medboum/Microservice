create function macaddr_eq(macaddr, macaddr) returns boolean
    language internal
as
$$macaddr_eq$$;

comment on function macaddr_eq(macaddr, macaddr) is 'implementation of = operator';

