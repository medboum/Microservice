create function mod(smallint, smallint) returns smallint
    language internal
as
$$int2mod$$;

comment on function mod(int2, int2) is 'modulus';

