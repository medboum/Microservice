create function pg_extension_config_dump(regclass, text) returns void
    language internal
as
$$pg_extension_config_dump$$;

comment on function pg_extension_config_dump(regclass, text) is 'flag an extension''s table contents to be emitted by pg_dump';

