create function log10(double precision) returns double precision
    language internal
as
$$dlog10$$;

comment on function log10(numeric) is 'base 10 logarithm';

