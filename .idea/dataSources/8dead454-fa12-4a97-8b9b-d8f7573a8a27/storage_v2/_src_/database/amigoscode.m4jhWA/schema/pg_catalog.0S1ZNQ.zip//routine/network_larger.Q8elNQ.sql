create function network_larger(inet, inet) returns inet
    language internal
as
$$network_larger$$;

comment on function network_larger(inet, inet) is 'larger of two';

