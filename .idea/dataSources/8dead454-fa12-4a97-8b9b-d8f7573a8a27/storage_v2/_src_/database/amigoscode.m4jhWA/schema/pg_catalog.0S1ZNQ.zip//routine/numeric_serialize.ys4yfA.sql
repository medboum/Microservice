create function numeric_serialize(internal) returns bytea
    language internal
as
$$numeric_serialize$$;

comment on function numeric_serialize(internal) is 'aggregate serial function';

