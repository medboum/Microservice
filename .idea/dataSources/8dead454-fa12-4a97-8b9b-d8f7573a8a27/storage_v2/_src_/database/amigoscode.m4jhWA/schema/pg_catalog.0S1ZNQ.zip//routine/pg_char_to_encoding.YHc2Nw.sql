create function pg_char_to_encoding(name) returns integer
    language internal
as
$$PG_char_to_encoding$$;

comment on function pg_char_to_encoding(name) is 'convert encoding name to encoding id';

