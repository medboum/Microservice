create function nameregexne(name, text) returns boolean
    language internal
as
$$nameregexne$$;

comment on function nameregexne(name, text) is 'implementation of !~ operator';

