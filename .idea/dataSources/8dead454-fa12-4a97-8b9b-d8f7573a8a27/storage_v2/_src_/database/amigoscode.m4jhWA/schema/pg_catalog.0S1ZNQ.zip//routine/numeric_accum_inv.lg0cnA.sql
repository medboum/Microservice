create function numeric_accum_inv(internal, numeric) returns internal
    language internal
as
$$numeric_accum_inv$$;

comment on function numeric_accum_inv(internal, numeric) is 'aggregate transition function';

