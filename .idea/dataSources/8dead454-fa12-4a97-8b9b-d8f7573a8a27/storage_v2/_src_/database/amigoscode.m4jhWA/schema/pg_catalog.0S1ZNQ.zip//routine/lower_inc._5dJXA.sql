create function lower_inc(anyrange) returns boolean
    language internal
as
$$range_lower_inc$$;

comment on function lower_inc(anymultirange) is 'is the multirange''s lower bound inclusive?';

