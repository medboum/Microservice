create function lseg_length(lseg) returns double precision
    language internal
as
$$lseg_length$$;

comment on function lseg_length(lseg) is 'implementation of @-@ operator';

