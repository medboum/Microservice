create function min_scale(numeric) returns integer
    language internal
as
$$numeric_min_scale$$;

comment on function min_scale(numeric) is 'minimum scale needed to represent the value';

