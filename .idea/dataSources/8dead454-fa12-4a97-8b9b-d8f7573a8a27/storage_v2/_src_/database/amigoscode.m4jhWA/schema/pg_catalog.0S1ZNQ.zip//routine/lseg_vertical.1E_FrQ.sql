create function lseg_vertical(lseg) returns boolean
    language internal
as
$$lseg_vertical$$;

comment on function lseg_vertical(lseg) is 'implementation of ?| operator';

