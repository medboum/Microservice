create function netmask(inet) returns inet
    language internal
as
$$network_netmask$$;

comment on function netmask(inet) is 'netmask of address';

