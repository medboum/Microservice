create function multirangesel(internal, oid, internal, integer) returns double precision
    language internal
as
$$multirangesel$$;

comment on function multirangesel(internal, oid, internal, int4) is 'restriction selectivity for multirange operators';

