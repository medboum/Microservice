create function path_add(path, path) returns path
    language internal
as
$$path_add$$;

comment on function path_add(path, path) is 'implementation of + operator';

