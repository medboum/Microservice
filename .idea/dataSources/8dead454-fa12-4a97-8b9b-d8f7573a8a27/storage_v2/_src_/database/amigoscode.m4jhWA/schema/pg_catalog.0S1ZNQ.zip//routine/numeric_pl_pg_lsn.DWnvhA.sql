create function numeric_pl_pg_lsn(numeric, pg_lsn) returns pg_lsn
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function numeric_pl_pg_lsn(numeric, pg_lsn) is 'implementation of + operator';

