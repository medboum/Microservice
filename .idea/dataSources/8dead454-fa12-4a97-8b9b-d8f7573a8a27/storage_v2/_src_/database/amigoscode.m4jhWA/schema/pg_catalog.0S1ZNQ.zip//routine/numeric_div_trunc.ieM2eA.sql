create function numeric_div_trunc(numeric, numeric) returns numeric
    language internal
as
$$numeric_div_trunc$$;

comment on function numeric_div_trunc(numeric, numeric) is 'trunc(x/y)';

