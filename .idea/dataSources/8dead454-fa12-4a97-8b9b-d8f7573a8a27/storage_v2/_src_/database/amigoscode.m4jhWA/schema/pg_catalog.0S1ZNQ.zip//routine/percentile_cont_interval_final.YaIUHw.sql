create function percentile_cont_interval_final(internal, double precision) returns interval
    language internal
as
$$percentile_cont_interval_final$$;

comment on function percentile_cont_interval_final(internal, float8) is 'aggregate final function';

