create function lseg_parallel(lseg, lseg) returns boolean
    language internal
as
$$lseg_parallel$$;

comment on function lseg_parallel(lseg, lseg) is 'implementation of ?|| operator';

