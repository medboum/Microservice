create function now() returns timestamp with time zone
    language internal
as
$$now$$;

comment on function now() is 'current transaction time';

