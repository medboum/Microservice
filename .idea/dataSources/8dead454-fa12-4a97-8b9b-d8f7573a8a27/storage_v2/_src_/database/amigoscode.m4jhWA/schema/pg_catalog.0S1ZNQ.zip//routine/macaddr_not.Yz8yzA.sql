create function macaddr_not(macaddr) returns macaddr
    language internal
as
$$macaddr_not$$;

comment on function macaddr_not(macaddr) is 'implementation of ~ operator';

