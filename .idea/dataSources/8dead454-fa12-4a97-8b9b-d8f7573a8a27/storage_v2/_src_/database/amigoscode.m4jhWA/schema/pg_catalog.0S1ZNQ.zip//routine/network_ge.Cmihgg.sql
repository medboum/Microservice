create function network_ge(inet, inet) returns boolean
    language internal
as
$$network_ge$$;

comment on function network_ge(inet, inet) is 'implementation of >= operator';

