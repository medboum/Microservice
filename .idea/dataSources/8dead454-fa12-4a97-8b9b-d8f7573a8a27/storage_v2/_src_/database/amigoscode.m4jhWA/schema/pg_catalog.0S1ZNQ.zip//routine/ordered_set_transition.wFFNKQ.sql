create function ordered_set_transition(internal, "any") returns internal
    language internal
as
$$ordered_set_transition$$;

comment on function ordered_set_transition(internal, any) is 'aggregate transition function';

