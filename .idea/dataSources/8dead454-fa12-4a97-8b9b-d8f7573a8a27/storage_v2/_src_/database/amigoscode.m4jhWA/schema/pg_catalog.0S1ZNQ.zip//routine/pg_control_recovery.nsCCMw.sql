create function pg_control_recovery(OUT min_recovery_end_lsn pg_lsn, OUT min_recovery_end_timeline integer, OUT backup_start_lsn pg_lsn, OUT backup_end_lsn pg_lsn, OUT end_of_backup_record_required boolean) returns record
    language internal
as
$$pg_control_recovery$$;

comment on function pg_control_recovery(out pg_lsn, out int4, out pg_lsn, out pg_lsn, out bool) is 'pg_controldata recovery state information as a function';

