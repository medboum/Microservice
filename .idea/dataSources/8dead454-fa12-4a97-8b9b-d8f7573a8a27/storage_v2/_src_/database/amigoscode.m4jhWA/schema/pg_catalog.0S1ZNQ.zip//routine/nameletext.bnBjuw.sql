create function nameletext(name, text) returns boolean
    language internal
as
$$nameletext$$;

comment on function nameletext(name, text) is 'implementation of <= operator';

