create function numeric_le(numeric, numeric) returns boolean
    language internal
as
$$numeric_le$$;

comment on function numeric_le(numeric, numeric) is 'implementation of <= operator';

