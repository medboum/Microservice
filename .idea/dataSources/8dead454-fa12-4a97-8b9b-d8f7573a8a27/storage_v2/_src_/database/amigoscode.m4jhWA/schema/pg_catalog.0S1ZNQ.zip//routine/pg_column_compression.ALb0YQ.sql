create function pg_column_compression("any") returns text
    language internal
as
$$pg_column_compression$$;

comment on function pg_column_compression(any) is 'compression method for the compressed datum';

