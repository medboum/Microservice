create function pg_get_serial_sequence(text, text) returns text
    language internal
as
$$pg_get_serial_sequence$$;

comment on function pg_get_serial_sequence(text, text) is 'name of sequence for a serial column';

