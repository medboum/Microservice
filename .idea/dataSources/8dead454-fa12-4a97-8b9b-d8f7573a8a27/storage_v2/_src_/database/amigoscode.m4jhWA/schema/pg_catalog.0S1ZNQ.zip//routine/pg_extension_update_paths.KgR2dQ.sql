create function pg_extension_update_paths(name name, OUT source text, OUT target text, OUT path text) returns SETOF record
    language internal
as
$$pg_extension_update_paths$$;

comment on function pg_extension_update_paths(name, out text, out text, out text) is 'list an extension''s version update paths';

