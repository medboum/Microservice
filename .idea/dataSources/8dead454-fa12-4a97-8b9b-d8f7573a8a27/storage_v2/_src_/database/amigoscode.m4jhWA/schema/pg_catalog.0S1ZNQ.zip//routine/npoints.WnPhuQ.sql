create function npoints(path) returns integer
    language internal
as
$$path_npoints$$;

comment on function npoints(polygon) is 'number of points';

