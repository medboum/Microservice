create function numeric(money) returns numeric
    language internal
as
$$cash_numeric$$;

comment on function numeric(float4) is 'convert float4 to numeric';

