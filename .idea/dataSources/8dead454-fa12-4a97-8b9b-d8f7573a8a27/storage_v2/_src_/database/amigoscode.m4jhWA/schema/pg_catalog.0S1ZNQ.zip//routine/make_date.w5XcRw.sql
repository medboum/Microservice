create function make_date(year integer, month integer, day integer) returns date
    language internal
as
$$make_date$$;

comment on function make_date(int4, int4, int4) is 'construct date';

