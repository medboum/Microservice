create function macaddr8_out(macaddr8) returns cstring
    language internal
as
$$macaddr8_out$$;

comment on function macaddr8_out(macaddr8) is 'I/O';

