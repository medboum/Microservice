create function multirange_union(anymultirange, anymultirange) returns anymultirange
    language internal
as
$$multirange_union$$;

comment on function multirange_union(anymultirange, anymultirange) is 'implementation of + operator';

