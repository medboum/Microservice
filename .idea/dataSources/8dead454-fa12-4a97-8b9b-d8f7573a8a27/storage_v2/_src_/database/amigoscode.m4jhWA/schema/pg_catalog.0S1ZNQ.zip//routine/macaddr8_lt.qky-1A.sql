create function macaddr8_lt(macaddr8, macaddr8) returns boolean
    language internal
as
$$macaddr8_lt$$;

comment on function macaddr8_lt(macaddr8, macaddr8) is 'implementation of < operator';

