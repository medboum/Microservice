create function numerictypmodin(cstring[]) returns integer
    language internal
as
$$numerictypmodin$$;

comment on function numerictypmodin(_cstring) is 'I/O typmod';

