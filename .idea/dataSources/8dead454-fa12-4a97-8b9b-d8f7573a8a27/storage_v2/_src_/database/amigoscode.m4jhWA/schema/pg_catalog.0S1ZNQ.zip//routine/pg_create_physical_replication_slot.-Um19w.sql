create function pg_create_physical_replication_slot(slot_name name, immediately_reserve boolean DEFAULT false, temporary boolean DEFAULT false, OUT slot_name name, OUT lsn pg_lsn) returns record
    language internal
as
$$pg_create_physical_replication_slot$$;

comment on function pg_create_physical_replication_slot(bool, bool, out name, out pg_lsn) is 'create a physical replication slot';

