create function multirange_overright_range(anymultirange, anyrange) returns boolean
    language internal
as
$$multirange_overright_range$$;

comment on function multirange_overright_range(anymultirange, anyrange) is 'implementation of &> operator';

