create function multirange_after_multirange(anymultirange, anymultirange) returns boolean
    language internal
as
$$multirange_after_multirange$$;

comment on function multirange_after_multirange(anymultirange, anymultirange) is 'implementation of >> operator';

