create function numrange(numeric, numeric) returns numrange
    language internal
as
$$range_constructor2$$;

comment on function numrange(numeric, numeric, text) is 'numrange constructor';

