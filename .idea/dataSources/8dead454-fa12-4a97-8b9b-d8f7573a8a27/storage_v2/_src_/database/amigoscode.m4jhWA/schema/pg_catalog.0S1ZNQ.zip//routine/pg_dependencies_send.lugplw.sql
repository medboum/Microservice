create function pg_dependencies_send(pg_dependencies) returns bytea
    language internal
as
$$pg_dependencies_send$$;

comment on function pg_dependencies_send(pg_dependencies) is 'I/O';

