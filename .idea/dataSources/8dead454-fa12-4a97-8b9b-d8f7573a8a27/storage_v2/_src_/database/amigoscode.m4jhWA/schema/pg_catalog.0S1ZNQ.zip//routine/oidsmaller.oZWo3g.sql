create function oidsmaller(oid, oid) returns oid
    language internal
as
$$oidsmaller$$;

comment on function oidsmaller(oid, oid) is 'smaller of two';

