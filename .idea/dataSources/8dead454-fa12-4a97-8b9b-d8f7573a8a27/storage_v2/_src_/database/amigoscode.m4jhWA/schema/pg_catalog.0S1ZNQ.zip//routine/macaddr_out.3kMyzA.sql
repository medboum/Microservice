create function macaddr_out(macaddr) returns cstring
    language internal
as
$$macaddr_out$$;

comment on function macaddr_out(macaddr) is 'I/O';

