create function path_recv(internal) returns path
    language internal
as
$$path_recv$$;

comment on function path_recv(internal) is 'I/O';

