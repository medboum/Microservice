create function lower(text) returns text
    language internal
as
$$lower$$;

comment on function lower(anymultirange) is 'lower bound of multirange';

