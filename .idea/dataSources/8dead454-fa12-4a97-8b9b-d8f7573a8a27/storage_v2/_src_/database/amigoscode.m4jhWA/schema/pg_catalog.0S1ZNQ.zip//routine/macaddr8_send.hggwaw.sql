create function macaddr8_send(macaddr8) returns bytea
    language internal
as
$$macaddr8_send$$;

comment on function macaddr8_send(macaddr8) is 'I/O';

