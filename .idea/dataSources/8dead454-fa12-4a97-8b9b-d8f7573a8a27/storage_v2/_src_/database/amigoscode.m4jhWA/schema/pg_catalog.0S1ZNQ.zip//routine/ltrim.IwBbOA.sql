create function ltrim(text, text) returns text
    language internal
as
$$ltrim$$;

comment on function ltrim(bytea, bytea) is 'trim selected bytes from left end of string';

