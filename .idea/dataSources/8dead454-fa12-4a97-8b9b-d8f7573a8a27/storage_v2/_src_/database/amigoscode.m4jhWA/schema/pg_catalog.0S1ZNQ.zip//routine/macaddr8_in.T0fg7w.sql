create function macaddr8_in(cstring) returns macaddr8
    language internal
as
$$macaddr8_in$$;

comment on function macaddr8_in(cstring) is 'I/O';

