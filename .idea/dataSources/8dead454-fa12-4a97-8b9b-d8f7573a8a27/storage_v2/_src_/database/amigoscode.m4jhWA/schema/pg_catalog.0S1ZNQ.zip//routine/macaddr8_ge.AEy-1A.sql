create function macaddr8_ge(macaddr8, macaddr8) returns boolean
    language internal
as
$$macaddr8_ge$$;

comment on function macaddr8_ge(macaddr8, macaddr8) is 'implementation of >= operator';

