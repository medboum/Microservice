create function pg_event_trigger_table_rewrite_reason() returns integer
    language internal
as
$$pg_event_trigger_table_rewrite_reason$$;

comment on function pg_event_trigger_table_rewrite_reason() is 'return reason code for table getting rewritten';

