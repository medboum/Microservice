create function numeric_var_samp(internal) returns numeric
    language internal
as
$$numeric_var_samp$$;

comment on function numeric_var_samp(internal) is 'aggregate final function';

