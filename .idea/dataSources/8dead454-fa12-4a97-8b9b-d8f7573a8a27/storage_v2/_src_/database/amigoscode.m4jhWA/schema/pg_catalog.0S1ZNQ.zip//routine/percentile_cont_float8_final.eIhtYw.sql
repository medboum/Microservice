create function percentile_cont_float8_final(internal, double precision) returns double precision
    language internal
as
$$percentile_cont_float8_final$$;

comment on function percentile_cont_float8_final(internal, float8) is 'aggregate final function';

