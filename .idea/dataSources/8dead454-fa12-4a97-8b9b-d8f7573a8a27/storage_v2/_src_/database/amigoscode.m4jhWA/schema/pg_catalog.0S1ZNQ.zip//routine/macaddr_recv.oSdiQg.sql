create function macaddr_recv(internal) returns macaddr
    language internal
as
$$macaddr_recv$$;

comment on function macaddr_recv(internal) is 'I/O';

