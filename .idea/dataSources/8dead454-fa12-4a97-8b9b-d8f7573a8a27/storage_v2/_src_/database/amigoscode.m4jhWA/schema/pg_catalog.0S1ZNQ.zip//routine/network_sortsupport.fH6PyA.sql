create function network_sortsupport(internal) returns void
    language internal
as
$$network_sortsupport$$;

comment on function network_sortsupport(internal) is 'sort support';

