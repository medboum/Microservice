create function namerecv(internal) returns name
    language internal
as
$$namerecv$$;

comment on function namerecv(internal) is 'I/O';

