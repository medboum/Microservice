create function multirange_le(anymultirange, anymultirange) returns boolean
    language internal
as
$$multirange_le$$;

comment on function multirange_le(anymultirange, anymultirange) is 'implementation of <= operator';

