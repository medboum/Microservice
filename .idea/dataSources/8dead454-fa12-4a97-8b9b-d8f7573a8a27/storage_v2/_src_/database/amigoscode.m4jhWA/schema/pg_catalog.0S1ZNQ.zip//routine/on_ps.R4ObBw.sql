create function on_ps(point, lseg) returns boolean
    language internal
as
$$on_ps$$;

comment on function on_ps(point, lseg) is 'implementation of <@ operator';

