create function numeric(money) returns numeric
    language internal
as
$$cash_numeric$$;

comment on function numeric(int2) is 'convert int2 to numeric';

