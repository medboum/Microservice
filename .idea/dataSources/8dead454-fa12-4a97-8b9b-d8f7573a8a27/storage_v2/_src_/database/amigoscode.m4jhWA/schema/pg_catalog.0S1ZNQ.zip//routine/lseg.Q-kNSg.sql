create function lseg(box) returns lseg
    language internal
as
$$box_diagonal$$;

comment on function lseg(box) is 'diagonal of';

