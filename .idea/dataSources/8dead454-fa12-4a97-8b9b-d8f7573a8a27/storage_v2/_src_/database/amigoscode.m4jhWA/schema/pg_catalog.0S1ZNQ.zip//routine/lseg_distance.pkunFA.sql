create function lseg_distance(lseg, lseg) returns double precision
    language internal
as
$$lseg_distance$$;

comment on function lseg_distance(lseg, lseg) is 'implementation of <-> operator';

