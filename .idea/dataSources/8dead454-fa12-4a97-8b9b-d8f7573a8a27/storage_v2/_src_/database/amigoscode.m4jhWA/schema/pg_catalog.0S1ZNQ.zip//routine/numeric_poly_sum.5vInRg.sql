create function numeric_poly_sum(internal) returns numeric
    language internal
as
$$numeric_poly_sum$$;

comment on function numeric_poly_sum(internal) is 'aggregate final function';

