create function lowrite(integer, bytea) returns integer
    language internal
as
$$be_lowrite$$;

comment on function lowrite(int4, bytea) is 'large object write';

