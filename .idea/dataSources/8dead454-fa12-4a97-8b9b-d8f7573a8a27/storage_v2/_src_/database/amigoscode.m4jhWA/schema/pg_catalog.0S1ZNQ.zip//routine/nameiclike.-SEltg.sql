create function nameiclike(name, text) returns boolean
    language internal
as
$$nameiclike$$;

comment on function nameiclike(name, text) is 'implementation of ~~* operator';

