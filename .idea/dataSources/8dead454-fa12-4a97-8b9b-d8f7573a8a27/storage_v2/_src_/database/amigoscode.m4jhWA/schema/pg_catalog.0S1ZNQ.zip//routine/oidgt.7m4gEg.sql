create function oidgt(oid, oid) returns boolean
    language internal
as
$$oidgt$$;

comment on function oidgt(oid, oid) is 'implementation of > operator';

