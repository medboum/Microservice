create function pg_indexam_has_property(oid, text) returns boolean
    language internal
as
$$pg_indexam_has_property$$;

comment on function pg_indexam_has_property(oid, text) is 'test property of an index access method';

