create function macaddr_sortsupport(internal) returns void
    language internal
as
$$macaddr_sortsupport$$;

comment on function macaddr_sortsupport(internal) is 'sort support';

