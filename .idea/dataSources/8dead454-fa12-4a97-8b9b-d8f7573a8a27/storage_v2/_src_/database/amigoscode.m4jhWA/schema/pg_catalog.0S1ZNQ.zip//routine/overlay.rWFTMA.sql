create function overlay(bytea, bytea, integer, integer) returns bytea
    language internal
as
$$byteaoverlay$$;

comment on function overlay(bit, bit, int4, int4) is 'substitute portion of bitstring';

